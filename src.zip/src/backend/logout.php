<?php
// logout.php
session_start();
session_destroy();

echo "Sesión cerrada correctamente.";
?>
