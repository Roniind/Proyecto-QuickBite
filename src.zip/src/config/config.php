<?php
define('ENVIRONMENT', 'nube_privada');
define('DB_HOST', '10.0.0.5');
define('ENABLE_FIREWALL', true);
?>
